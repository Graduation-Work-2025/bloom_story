package com.example.bloom.util

import android.content.Context  // ⬅️ 꼭 필요합니다!

object TokenProvider {
    private const val PREF_NAME = "auth_pref"
    private const val KEY_TOKEN = "auth_token"

    fun setToken(token: String, context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_TOKEN, token).apply()
    }

    fun getToken(context: Context): String? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_TOKEN, null)
    }
}
