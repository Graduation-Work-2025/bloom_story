package com.example.bloom.network

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory

object RetrofitInstance {
    private const val BASE_URL = "https://bloom-story.kro.kr/"

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            // String(raw) 응답도 처리하려면 Scalars 먼저
            .addConverterFactory(ScalarsConverterFactory.create())
            .addConverterFactory(GsonConverterFactory.create())
            .client(
                OkHttpClient.Builder()
                    // 필요 시 공통 헤더나 로깅 인터셉터 추가
                    .build()
            )
            .build()
            .create(ApiService::class.java)
    }
}
