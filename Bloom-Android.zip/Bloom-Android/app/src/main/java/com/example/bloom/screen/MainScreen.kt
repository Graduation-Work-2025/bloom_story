package com.example.bloom.screen

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.bloom.R
import com.example.bloom.data.FeedFlower
import com.example.bloom.data.getFlowerImageForEmotion
import com.example.bloom.network.WebSocketManager
import com.example.bloom.util.TokenProvider
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson
import com.google.maps.android.compose.*
import ua.naiksoftware.stomp.dto.StompMessage

@Composable
fun MainScreen(navController: NavController) {
    val context = LocalContext.current
    val gson = remember { Gson() }

    var feedList by remember { mutableStateOf<List<FeedFlower>>(emptyList()) }
    var userLocation by remember { mutableStateOf<LatLng?>(null) }

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(36.7631, 127.2827), 14f)
    }

    val requestPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(context, "위치 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
        }
    }

    // 🌐 WebSocket 연결 및 메시지 수신
    LaunchedEffect(Unit) {
        val token = TokenProvider.getToken(context) ?: return@LaunchedEffect

        WebSocketManager.connect(
            token = token,
            onConnect = {
                WebSocketManager.subscribeToStoryUpdates { message: StompMessage ->
                    try {
                        val jsonArray = gson.fromJson(message.payload, List::class.java)
                        val flowers = jsonArray.mapNotNull { item ->
                            try {
                                val json = gson.toJsonTree(item).asJsonObject
                                val id = json["id"]?.asInt ?: return@mapNotNull null
                                val lat = json["latitude"]?.asDouble ?: return@mapNotNull null
                                val lng = json["longitude"]?.asDouble ?: return@mapNotNull null
                                val emotion = json["emotion_id"]?.asInt ?: 1
                                FeedFlower(id, lat, lng, getFlowerImageForEmotion(emotion))
                            } catch (e: Exception) {
                                null
                            }
                        }
                        Handler(Looper.getMainLooper()).post {
                            feedList = flowers
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "파싱 오류: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onError = {
                Toast.makeText(context, "WebSocket 연결 실패: ${it.message}", Toast.LENGTH_SHORT).show()
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(mapType = MapType.NORMAL),
            contentPadding = PaddingValues(top = 400.dp)
        ) {
            feedList.forEach { flower ->
                Marker(
                    state = MarkerState(LatLng(flower.latitude, flower.longitude)),
                    title = "스토리",
                    onClick = {
                        navController.navigate("post_detail/${flower.id}")
                        true
                    }
                )
            }

            userLocation?.let {
                Marker(
                    state = MarkerState(position = it),
                    title = "내 위치"
                )
            }
        }

        // 메뉴 버튼
        var menuExpanded by remember { mutableStateOf(false) }
        IconButton(
            onClick = { menuExpanded = !menuExpanded },
            modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_menu),
                contentDescription = "메뉴",
                modifier = Modifier.size(40.dp)
            )
        }

        DropdownMenu(
            expanded = menuExpanded,
            onDismissRequest = { menuExpanded = false },
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            DropdownMenuItem(text = { Text("감정 달력", fontSize = 18.sp) }, onClick = {})
            DropdownMenuItem(text = { Text("친구", fontSize = 18.sp) }, onClick = { navController.navigate("add_friend") })
            DropdownMenuItem(text = { Text("설정", fontSize = 18.sp) }, onClick = {})
            DropdownMenuItem(text = { Text("글 목록", fontSize = 18.sp) }, onClick = { navController.navigate("post_list") })
            DropdownMenuItem(text = { Text("내 정보 수정", fontSize = 18.sp) }, onClick = { navController.navigate("edit_profile") })
            DropdownMenuItem(text = { Text("감정 정원", fontSize = 18.sp) }, onClick = { navController.navigate("emotion_garden") })
            DropdownMenuItem(text = { Text("오늘 감정", fontSize = 18.sp) }, onClick = {})
        }

        // 글쓰기 버튼
        FloatingActionButton(
            onClick = { navController.navigate("create_post") },
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primary
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_add),
                contentDescription = "글 작성"
            )
        }
    }
}