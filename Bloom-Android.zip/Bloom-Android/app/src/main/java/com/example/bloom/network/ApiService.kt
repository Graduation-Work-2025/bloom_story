package com.example.bloom.network

import com.example.bloom.data.*
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    // — 사용자/프로필
    @POST("users/signup")
    suspend fun signUp(@Body info: SignUpRequestDto): Response<Unit>

    @POST("users/login")
    suspend fun login(@Body info: LoginRequestDto): Response<LoginResponseDto>

    @GET("users/profile")
    suspend fun getUserProfile(@Header("Authorization") token: String): Response<UserProfileResponse>

    @PUT("users/update")
    suspend fun updateUserProfile(
        @Header("Authorization") token: String,
        @Body info: UpdateProfileRequestDto
    ): Response<UserProfileResponse>

    // — 스토리
    @GET("story/my")
    suspend fun getMyStories(@Header("Authorization") token: String): Response<List<StoryData>>

    @GET("story/{id}")
    suspend fun getStoryById(
        @Header("Authorization") token: String,
        @Path("id") id: Int
    ): Response<StoryData>

    @POST("story")
    suspend fun postStory(
        @Header("Authorization") token: String,
        @Body request: StoryPostRequest
    ): Response<StoryPostResponse>

    // — S3 Presigned URL (업로드용 URL 발급) :contentReference[oaicite:0]{index=0}:contentReference[oaicite:1]{index=1}
    @POST("s3/upload/url")
    suspend fun getPresignedUrl(
        @Body req: PresignedUrlRequest
    ): Response<PresignedUrlResponse>

    // — (선택) Retrofit으로 직접 이미지 업로드할 때 쓰기
    @Multipart
    @POST("upload/image")
    suspend fun uploadImage(
        @Part image: MultipartBody.Part
    ): Response<UploadImageResponse>
}
