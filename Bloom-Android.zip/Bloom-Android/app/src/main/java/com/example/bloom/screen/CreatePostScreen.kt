package com.example.bloom.screen

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.bloom.data.*
import com.example.bloom.network.RetrofitInstance
import com.example.bloom.network.ImageUploader
import com.example.bloom.util.TokenProvider
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import android.content.Context
import com.example.bloom.network.WebSocketManager


@Composable
fun CreatePostScreen(navController: NavController) {
    val context = LocalContext.current
    val activity = context as? Activity

    var postContent by remember { mutableStateOf("") }
    var selectedEmotion by remember { mutableStateOf("😃 기쁨") }
    var selectedPrivacy by remember { mutableStateOf("전체 공개") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var showEmotionPicker by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> selectedImageUri = uri }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // — 상단 제목+내용 입력
        Column {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ navController.popBackStack() }) {
                    Icon(Icons.Filled.Close, contentDescription = null)
                }
                Text("새 스토리 작성", fontSize = 22.sp)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = postContent,
                onValueChange = { postContent = it },
                label = { Text("내용을 입력하세요") },
                modifier = Modifier.fillMaxWidth().height(150.dp),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(12.dp))

            Button({ imagePicker.launch("image/*") }) {
                Text("이미지 선택")
            }
            selectedImageUri?.let {
                Image(
                    painter = rememberAsyncImagePainter(it),
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth().height(200.dp).padding(vertical = 8.dp)
                )
            }

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("감정 선택: $selectedEmotion")
                Button({ showEmotionPicker = true }) { Text("변경") }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth()
                    .clickable { showPrivacyDialog = true }
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("공개 범위: $selectedPrivacy")
            }
            Divider()
        }

        // — 하단 버튼
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // 취소
            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier.weight(1f).height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
            ) { Text("취소", color = Color.White) }

            // 심기
            Button(
                onClick = {
                    // 1) 필수 입력 체크
                    if (postContent.isBlank()) {
                        Toast.makeText(context, "내용을 입력해주세요.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (selectedImageUri == null) {
                        Toast.makeText(context, "이미지를 선택해주세요.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    // 2) 위치 권한 체크
                    if (activity == null ||
                        ContextCompat.checkSelfPermission(
                            context, Manifest.permission.ACCESS_FINE_LOCATION
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        activity?.let {
                            ActivityCompat.requestPermissions(
                                it, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1234
                            )
                        }
                        Toast.makeText(context, "위치 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    // 3) 마지막 위치 가져오기
                    fusedLocationClient.lastLocation
                        .addOnSuccessListener { loc ->
                            if (loc == null) {
                                Toast.makeText(context, "위치 정보를 가져올 수 없습니다.", Toast.LENGTH_SHORT).show()
                            } else {
                                // 실제 업로드 & 서버 전송
                                uploadStory(
                                    context, navController,
                                    postContent, selectedEmotion, selectedPrivacy,
                                    selectedImageUri!!, loc.latitude, loc.longitude
                                )
                            }
                        }
                        .addOnFailureListener {
                            Toast.makeText(context, "위치 조회 실패", Toast.LENGTH_SHORT).show()
                        }
                },
                modifier = Modifier.weight(1f).height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF55996F))
            ) { Text("심기", color = Color.White) }
        }
    }

    // — 다이얼로그들
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("공개 범위 선택") },
            text = {
                Column {
                    listOf("전체 공개", "비공개").forEach { opt ->
                        Text(opt, Modifier.fillMaxWidth().clickable {
                            selectedPrivacy = opt
                            showPrivacyDialog = false
                        }.padding(8.dp))
                    }
                }
            },
            confirmButton = {
                TextButton({ showPrivacyDialog = false }) { Text("닫기") }
            }
        )
    }

    if (showEmotionPicker) {
        AlertDialog(
            onDismissRequest = { showEmotionPicker = false },
            title = { Text("감정 선택") },
            text = {
                Column(
                    Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                ) {
                    emotionCategories.forEach { (cat, subs) ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(cat, Modifier.clickable {
                                selectedEmotion = cat
                                showEmotionPicker = false
                            }.padding(4.dp))
                            subs.forEach { sub ->
                                Text(sub, Modifier.clickable {
                                    selectedEmotion = sub
                                    showEmotionPicker = false
                                }.padding(4.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton({ showEmotionPicker = false }) { Text("닫기") }
            }
        )
    }
}

// — 업로드 & 서버 전송 분리 함수
private fun uploadStory(
    context: Context,
    navController: NavController,
    content: String,
    emotion: String,
    privacy: String,
    imageUri: Uri,
    lat: Double,
    lng: Double
) {
    val tmp = runCatching {
        context.contentResolver.openInputStream(imageUri)!!.use { ins ->
            File.createTempFile("upload_", ".png", context.cacheDir).apply {
                outputStream().use { out -> ins.copyTo(out) }
            }
        }
    }.getOrNull()

    if (tmp == null || !tmp.exists()) {
        Toast.makeText(context, "이미지를 처리할 수 없습니다.", Toast.LENGTH_SHORT).show()
        return
    }

    CoroutineScope(Dispatchers.IO).launch {
        try {
            val rawToken = TokenProvider.getToken(context)
            if (rawToken.isNullOrBlank()) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "로그인이 필요합니다.", Toast.LENGTH_SHORT).show()
                }
                return@launch
            }
            val token = rawToken

            val pres = RetrofitInstance.api.getPresignedUrl(
                PresignedUrlRequest(
                    content_length = tmp.length(),
                    content_type = "image/png",
                    file_name = tmp.name
                )
            )

            if (!pres.isSuccessful || pres.body() == null) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "이미지 URL 요청 실패", Toast.LENGTH_SHORT).show()
                }
                return@launch
            }

            val uploadInfo = pres.body()!!
            val fileUrl = uploadInfo.file_url
            if (fileUrl.isNullOrBlank()) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "파일 URL 없음", Toast.LENGTH_SHORT).show()
                }
                return@launch
            }

            val uploaded = ImageUploader.uploadImageToS3(uploadInfo.pre_signed_url, tmp)
            if (!uploaded) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "이미지 업로드 실패", Toast.LENGTH_SHORT).show()
                }
                return@launch
            }

            val story = StoryPostRequest(
                token = token,
                request = StoryContent(
                    content = content,
                    longitude = lng,
                    latitude = lat,
                    sharing_type = if (privacy == "전체 공개") "PUBLIC" else "PRIVATE",
                    emotion_id = getEmotionId(emotion),
                    image_url = fileUrl
                )
            )

            val result = RetrofitInstance.api.postStory("Bearer $token", story)

            withContext(Dispatchers.Main) {
                if (result.isSuccessful) {
                    // ✅ WebSocket으로 위치 재요청 → 마커 즉시 반영
                    WebSocketManager.sendMessage(
                        destination = "/app/story",
                        message = """{
            "domain": "story",
            "command": "get_stories",
            "token": "$token",
            "request": {
                "longitude": $lng,
                "latitude": $lat
            }
        }""".trimIndent()
                    )

                    Toast.makeText(context, "스토리 등록 완료!", Toast.LENGTH_SHORT).show()
                    navController.navigate("main")
                } else {
                    Toast.makeText(context, "스토리 등록 실패: ${result.code()}", Toast.LENGTH_SHORT).show()
                }
            }

        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "에러 발생: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

// — 감정 데이터
private val emotionCategories = listOf(
    "기쁨" to listOf("신남","만족감","설렘","행복감"),
    "슬픔" to listOf("외로움","우울","실망","허무"),
    "놀람" to listOf("당황","경이로움","혼란","신기"),
    "분노" to listOf("짜증","답답","억울","분개"),
    "공포" to listOf("불안","긴장","두려움","겁남"),
    "혐오" to listOf("불쾌","역겨움","거부감","싫증")
)

// — 감정 → ID
private fun getEmotionId(emotion: String): Int = when (emotion) {
    "기쁨","신남","만족감","설렘","행복감" -> 6
    "슬픔","외로움","우울","실망","허무" -> 5
    "놀람","당황","경이로움","혼란","신기" -> 1
    "분노","짜증","답답","억울","분개" -> 4
    "공포","불안","긴장","두려움","겁남" -> 3
    "혐오","불쾌","역겨움","거부감","싫증" -> 2
    else -> 0
}