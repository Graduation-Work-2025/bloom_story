package com.example.bloom.network

import android.util.Log
import io.reactivex.disposables.Disposable
import ua.naiksoftware.stomp.Stomp
import ua.naiksoftware.stomp.StompClient
import ua.naiksoftware.stomp.dto.LifecycleEvent
import ua.naiksoftware.stomp.dto.StompMessage

object WebSocketManager {

    private const val SOCKET_URL = "wss://bloom-story.kro.kr/ws/unity"
    private const val TAG = "WebSocket"

    private var stompClient: StompClient? = null
    private var lifecycleDisposable: Disposable? = null
    private var storySubscription: Disposable? = null

    fun connect(
        token: String,
        onConnect: () -> Unit = {},
        onError: (Throwable) -> Unit = {}
    ) {
        if (stompClient?.isConnected == true) return

        stompClient = Stomp.over(Stomp.ConnectionProvider.OKHTTP, SOCKET_URL)

        lifecycleDisposable = stompClient?.lifecycle()?.subscribe { event ->
            when (event.type) {
                LifecycleEvent.Type.OPENED -> {
                    Log.d(TAG, "WebSocket 연결됨")
                    onConnect()
                }
                LifecycleEvent.Type.ERROR -> {
                    Log.e(TAG, "WebSocket 오류: ${event.exception}")
                    onError(event.exception ?: Throwable("Unknown error"))
                }
                LifecycleEvent.Type.CLOSED -> {
                    Log.d(TAG, "WebSocket 연결 종료됨")
                }
                LifecycleEvent.Type.FAILED_SERVER_HEARTBEAT -> {
                    Log.w(TAG, "WebSocket 핑 실패")
                }
            }
        }

        stompClient?.connect(listOf(ua.naiksoftware.stomp.dto.StompHeader("Authorization", "Bearer $token")))
    }

    fun subscribeToStoryUpdates(onMessageReceived: (StompMessage) -> Unit) {
        storySubscription = stompClient?.topic("/user/queue/story")
            ?.subscribe { stompMessage ->
                Log.d(TAG, "WebSocket 수신: ${stompMessage.payload}")
                onMessageReceived(stompMessage)
            }
    }


    fun disconnect() {
        lifecycleDisposable?.dispose()
        storySubscription?.dispose()
        stompClient?.disconnect()
        stompClient = null
    }

    fun sendMessage(destination: String, message: String) {
        stompClient?.send(destination, message)?.subscribe()
    }
}
