package com.example.bloom.network

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

object ImageUploader {
    private val client = OkHttpClient()

    /**
     * presignedUrl 에 파일을 PUT 방식으로 업로드합니다.
     * @return 성공(true) / 실패(false)
     */
    fun uploadImageToS3(presignedUrl: String, file: File): Boolean {
        // contentType 은 서버에서 image/png 으로 고정되어 있으므로 png 로 지정
        val mediaType = "image/png".toMediaType()
        val body = file.asRequestBody(mediaType)

        val request = Request.Builder()
            .url(presignedUrl)
            .put(body)
            .build()

        client.newCall(request).execute().use { resp ->
            return resp.isSuccessful
        }
    }
}