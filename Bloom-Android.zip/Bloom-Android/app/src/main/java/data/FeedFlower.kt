package com.example.bloom.data

import com.example.bloom.R

data class FeedFlower(
    val id: Int,
    val latitude: Double,
    val longitude: Double,
    val imageRes: Int
)

fun getFlowerImageForEmotion(emotionId: Int): Int {
    return when (emotionId) {
        1 -> R.drawable.flower1
        2 -> R.drawable.flower2
        3 -> R.drawable.flower3
        4 -> R.drawable.flower4
        5 -> R.drawable.flower5
        6 -> R.drawable.flower6
        7 -> R.drawable.flower7
        else -> R.drawable.flower_default
    }
}